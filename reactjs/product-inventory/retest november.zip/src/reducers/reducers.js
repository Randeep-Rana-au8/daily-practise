import { ADD_PRODUCT, DELETE_PRODUCT } from "../actions/actionsType";

const initialState = {
  products: [],
};

const reducers = (state = initialState, action) => {
  switch (action.type) {
    case ADD_PRODUCT:
      console.log(action.data);
      return {
        ...state,
        products: [...state.products, action.data],
      };
    case DELETE_PRODUCT:
      const allProducts = state.products.filter(
        (product) => product.id !== action.id
      );
      return {
        ...state,
        products: allProducts,
      };
    default:
      return {
        ...state,
      };
  }
};

export default reducers;
